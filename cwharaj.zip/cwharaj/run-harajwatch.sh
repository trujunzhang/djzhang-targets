#!/usr/bin/env bash

scrapy crawl harajwatch --set LOG_FILE=haraj-watch.log