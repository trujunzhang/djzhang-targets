#!/usr/bin/env bash

scrapy crawl haraj --set LOG_FILE=haraj.log